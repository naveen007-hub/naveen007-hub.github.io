<?php
$lang["pdftickets_thankyou"] = 'Thank You';
$lang["pdftickets_download_link"] = '%1$sDownload%2$s your tickets as a PDF file';
?>
