<?php

require_once (FS_PATH . "plugins/pdftickets/languages/default.php");

?>
