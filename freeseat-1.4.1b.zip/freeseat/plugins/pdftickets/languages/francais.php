<?php

require_once (FS_PATH . "plugins/pdftickets/languages/default.php");

$lang["pdftickets_download_link"] = '%1$sT�l�chargez%2$s vos billets au format PDF';

?>
