<?php

$lang['csvnames_download'] = "Download";
$lang['csvnames_link'] = "unique names";

?>
