<?php

require_once (FS_PATH . "plugins/csvnames/languages/default.php");

$lang['csvnames_download'] = "T�l�chargement";
$lang['csvnames_link'] = "noms uniques";

?>
