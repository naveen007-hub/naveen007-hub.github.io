<?php

function csvnames_info() {
    return array
	('english_name' => 'CSV Names',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
   'category' => 'operator',
	 'summary' => 'Allows the admin to export unique names and addresses in csv format.',
	 'details' => 'A new link is added to the booking list page. When clicked a file of unique names and addresses are downloaded to the user.');
}

?>
