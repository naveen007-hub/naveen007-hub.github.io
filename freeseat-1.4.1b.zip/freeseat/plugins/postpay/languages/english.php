<?php

require_once (FS_PATH . "plugins/postpay/languages/default.php");

?>
