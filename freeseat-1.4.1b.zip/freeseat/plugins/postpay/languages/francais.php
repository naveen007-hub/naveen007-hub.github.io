<?php

require_once (FS_PATH . "plugins/postpay/languages/default.php");

$lang["postpay_emailsent"] = <<<EOD

<h2>Payer des billets d�j� r�serv�s</h2>
<p class="main">Nous vous avons maintenant envoy� un e-mail contenant
des informations sur vos billets. Veuillez v�rifier votre courrier et
suivre les instructions qu'il contient.

Merci!
</p>
EOD;
$lang["postpay_intro"] = <<<EOD

<h2>Payer des billets d�j� r�serv�s</h2>

<p class='main'>Si vous avez r�serv� des billets mais ne les avez pas
encore pay�s, veuillez entrer l'adresse e-mail utilis�e au moment de
la r�servation, puis cliquez Envoyer.</p>

<p class='main'>Vous recevrez ensuite un e-mail contenant un lien vers
cette page. Une fois votre identit� confirm�e vous pourrez effectuer le
paiement en ligne.</p>

<p class='main'>Adresse e-mail: %1\$s</p>

<p class='main'>(Si vous n'aviez pas fourni d'adresse e-mail au moment
de la r�servation, ou si vous n'y avez plus acc�s, veuillez nous
contacter directement.)</p>


EOD;
$lang["postpay_notickets"] = <<<EOD
Aucun billet %1\$s a �t� trouv� pour cette adresse e-mail.  Avez-vous
utilis� la m�me adresse qu'au moment de la r�servation?  Si non, vous
pouvez essayer � nouveau. Si vous pensez qu'il y a erreur, veuillez
nous contacter.

EOD;


?>
