<?php

function postpay_info() {
    return array
	('english_name' => 'Post-pay',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
   'category' => 'payment',
	 'summary' => 'Lets the user pay for previously booked tickets',
	 'details' => 'Puts a link on the front page that lets a user request to make a payment for previously booked tickets. Authentication is done through the email address they gave when booking.');
}

?>
