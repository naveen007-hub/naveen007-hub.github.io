<?php

require_once (FS_PATH . "plugins/groupdiscount/languages/default.php");

?>
