<?php

require_once (FS_PATH . "plugins/groupdiscount/languages/default.php");

$lang['groupdiscount'] = 'Rabais de groupe';
$lang['groupdiscount_min'] = 'Nombre de places requis pour un rabais de groupe';
$lang['groupdiscount_perseat'] = 'Par place';

?>
