<?php

$lang['groupdiscount'] = 'Group Discount';
$lang['groupdiscount_min'] = 'Minimum number of paid seats required for group discount';
$lang['groupdiscount_perseat'] = 'Per Seat';

?>
