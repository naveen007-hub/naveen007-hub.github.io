<?php

require_once (FS_PATH . "plugins/seasontickets/languages/default.php");

?>
