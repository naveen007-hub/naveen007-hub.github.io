<?php

function csvdump_info() {
    return array
	('english_name' => 'CSV dump',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'operator',
	 'summary' => 'Allows the admin to export bookings in csv format.',
	 'details' => 'The link is added to the booking list page. ');
}

?>