<?php

require_once (FS_PATH . "plugins/config/languages/default.php");

?>
