<?php
$lang['seatedit_copy'] = 'Copy';
$lang['seatedit_edit_sn'] = 'Row #';
$lang['seatedit_edit_sn_title'] = 'Edit Seat Numbers';
$lang['seatedit_error_cant_delete'] = 'There are %1$d seats booked for that theatre and zone. Please erase them with the MySQL command line and try again.';
$lang['seatedit_extra'] = 'extra';
$lang['seatedit_extra_title'] = 'Edit Extra';
$lang['seatedit_fillselection'] = 'Fill Selection';
$lang['seatedit_fplink'] = 'Create/edit seatmaps';
$lang['seatedit_load'] = 'Load';
$lang['seatedit_ltr'] = 'Left to Right';
$lang['seatedit_more_rows'] = 'More Rows';
$lang['seatedit_more_cols'] = 'More Columns';
$lang['seatedit_paste'] = 'Paste';
$lang['seatedit_renum_rows'] = 'Renumber Rows Automatically:';
$lang['seatedit_rtl'] = 'Right to Left';
$lang['seatedit_save'] = 'Save';
$lang['seatedit_select'] = 'Select';
$lang['seatedit_subset_all'] = "All Numbers";
$lang['seatedit_subset_even'] = "Even numbers";
$lang['seatedit_subset_odd'] = 'Odd Numbers';
$lang['seatedit_theatre'] = 'Theatre';
$lang['seatedit_vert_indep'] = "Independent Rows";
$lang['seatedit_vert_ttb'] = "Top to Bottom";
$lang['seatedit_vert_btt'] = "Bottom to Top";
$lang['seatedit_with_value'] = "with value";
$lang['seatedit_zone'] = 'Zone';
?>