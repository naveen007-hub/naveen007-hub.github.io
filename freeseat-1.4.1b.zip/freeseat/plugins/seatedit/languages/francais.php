<?php
$lang['seatedit_copy'] = 'Copier';
$lang['seatedit_edit_sn'] = '1 2 3'; // no there's no room for "# si�ge"!
$lang['seatedit_edit_sn_title'] = '�dition num�ros places';
$lang['seatedit_error_cant_delete'] = 'Il y a %1$d r�servations concernant ce th��tre et cette zone. Veuillez les supprimer � l\'aide de la ligne de commande mySQL et r�essayer.';
$lang['seatedit_extra'] = 'extra';
$lang['seatedit_extra_title'] = '�dition infos suppl�mentaires';
$lang['seatedit_fillselection'] = 'Remplir s�lection';
$lang['seatedit_fplink'] = 'Cr�er/�diter des plans de salle';
$lang['seatedit_load'] = 'Ouvrir';
$lang['seatedit_ltr'] = 'De gauche � droite';
$lang['seatedit_more_rows'] = 'Ajouter des rang�es';
$lang['seatedit_more_cols'] = 'Ajouter des colonnes';
$lang['seatedit_paste'] = 'Coller';
$lang['seatedit_renum_rows'] = 'Renum�roter les rang�es automatiquement&nbsp;:';
$lang['seatedit_rtl'] = 'De droite � gauche';
$lang['seatedit_save'] = 'Enregistrer';
$lang['seatedit_subset_all'] = "Tous les nombres";
$lang['seatedit_subset_even'] = "Pairs";
$lang['seatedit_subset_odd'] = "Impairs";
$lang['seatedit_theatre'] = 'Th��tre';
$lang['seatedit_vert_indep'] = "Rang�es ind�pendantes";
$lang['seatedit_vert_ttb'] = "De haut en bas";
$lang['seatedit_vert_btt'] = "De bas en haut";
$lang['seatedit_with_value'] = "avec la valeur";
$lang['seatedit_zone'] = 'Zone';
?>