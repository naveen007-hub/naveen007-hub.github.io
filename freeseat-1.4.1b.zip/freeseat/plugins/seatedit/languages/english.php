<?php

require_once (FS_PATH . "plugins/seatedit/languages/default.php");

?>
