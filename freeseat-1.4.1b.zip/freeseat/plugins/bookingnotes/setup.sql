use $db;

alter table booking add column notes varchar(255);
