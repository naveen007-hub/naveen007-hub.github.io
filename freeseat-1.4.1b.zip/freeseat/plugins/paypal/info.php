<?php
function paypal_info() {
    return array
	('english_name' => 'Paypal',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'payment',
	 'summary' => 'Enables credit card payment with paypal.',
	 'details' => 'Enables credit card payment with paypal.');
}
?>