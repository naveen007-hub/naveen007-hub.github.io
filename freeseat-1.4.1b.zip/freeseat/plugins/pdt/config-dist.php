<?php

/*** PayPal PDT Configuration ***/

/* Leave this section alone it you are not using Paypal */

// $plugins[]="pdt"; // uncomment this if you want to use PayPal PDT
/* Insert here the Payment Data Transfer authorization code.  This can be 
obtained from the Paypal web site.  */
// @type string
 //$PDT_auth_token="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";


?>
