<?php

$lang["pdt_failure_page"] = <<<EOD
<h3>We're sorry, but your payment was not completed.</h3>
<p class='main'>You may try again, or contact the office for assistance.</p>
<p class='main'>Thank you for your patience.</p><br>
<a href='%1\$s'>Click here to try again</a>
EOD;

?>
