<?php

require_once (FS_PATH . "plugins/pdt/languages/default.php");

?>
