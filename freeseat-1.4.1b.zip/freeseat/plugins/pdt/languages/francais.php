<?php

require_once (FS_PATH . "plugins/pdt/languages/default.php");

$lang["pdt_failure_page"] = <<<EOD
<h3>Le paiement n'a malheureusement pas pu �tre effectu�.</h3>
<p class='main'>Vous pouvez r�essayer, ou contacter le bureau des r�servations pour assistance.</p>
<p class='main'>Merci pour votre patience.</p><br>
<a href='%1\$s'>Cliquez ici pour r�essayer</a>.
EOD;

?>
