<?php
$lang["disableseats"] = 'Maintain Disabled Seating For A Show';
$lang["seedisabledseats"] = 'Mark seats for this show as %1$sDisabled seating%2$s (Administrator only)';

?>