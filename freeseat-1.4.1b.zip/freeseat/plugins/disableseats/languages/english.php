<?php

require_once (FS_PATH . "plugins/disableseats/languages/default.php");

?>