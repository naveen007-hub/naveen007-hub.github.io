<?php

require_once (FS_PATH . "plugins/disableseats/languages/default.php");

$lang["disableseats"] = "Gestion des si�ges d�sactiv�s d'un spectacle";
$lang["seedisabledseats"] = '%1$sD�sactiver%2$s des si�ges de ce spectacle (pour administrateurs seulement)';

?>