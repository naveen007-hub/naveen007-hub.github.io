<?php

/*** Klikandpay configuration ***/

/* Leave this section commented if you are not using Klikandpay.

To use Klikandpay, you must uncomment and set the variables below to
the proper values for your account.  */

// $plugins[]="klikandpay";
// @type string
// $klikandpayid = "1234567890"; // example

/* only clients with ip $ip such that ($ip & $klikconfirm_netmask) =
  $klikconfirm_clients are allowed to connect to klikconfirm.php */

// @type string
// $klikconfirm_clients = "1.2.3.0"; // example
// @type string
// $klikconfirm_netmask = "255.255.255.0"; // example

?>