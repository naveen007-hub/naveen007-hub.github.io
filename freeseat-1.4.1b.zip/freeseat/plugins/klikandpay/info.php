<?php

function klikandpay_info() {
    return array
	('english_name' => 'Klikandpay',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'payment',
	 'summary' => 'Enables credit card payment with klikandpay.',
	 'details' => 'Enables credit card payment with klikandpay.');
}

?>