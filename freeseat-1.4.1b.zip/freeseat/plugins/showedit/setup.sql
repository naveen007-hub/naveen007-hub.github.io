GRANT INSERT,UPDATE ON $db.shows TO $adminuser;
GRANT INSERT,UPDATE,DELETE ON $db.price TO $adminuser;
GRANT INSERT,UPDATE ON $db.spectacles TO $adminuser;
GRANT INSERT,UPDATE,DELETE ON $db.class_comment TO $adminuser;
