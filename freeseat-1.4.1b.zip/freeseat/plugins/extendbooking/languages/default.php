<?php

$lang['extendbooking_extend'] = '%1$sExtend%2$s expiration date';

?>
