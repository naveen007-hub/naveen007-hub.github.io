<?php

require_once (FS_PATH . "plugins/extendbooking/languages/default.php");

?>
