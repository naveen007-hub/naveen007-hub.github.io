<?php

function extendbooking_info() {
    return array
	('english_name' => 'Extend booking',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'operator',
	 'summary' => 'Allows the admin to postpone the expiration of any booking.',
	 'details' => 'Adds a button "Extend" to let an administrator delay the expiration of selected unpaid bookings, when a customer requests more time to make the payment.');
}

?>
