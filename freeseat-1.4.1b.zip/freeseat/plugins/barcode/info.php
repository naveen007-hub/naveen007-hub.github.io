<?php

function barcode_info() {
    return array
	('english_name' => 'Barcode',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'tickets',
	 'summary' => 'Adds barcodes on tickets, and interfaces with USB barcode readers',
	 'details' => 'Adds a barcode on tickets. ');
}

?>