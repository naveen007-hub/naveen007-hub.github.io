<?php

require_once (FS_PATH . "plugins/castpw/languages/default.php");

?>
