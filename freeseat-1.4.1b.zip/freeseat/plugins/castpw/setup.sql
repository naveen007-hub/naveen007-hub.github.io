use $db;

alter table spectacles add column castpw varchar(64) NOT NULL;


