<?php

function adminprint_info() {
    return array
	('english_name' => 'Admin print',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'operator',
	 'summary' => 'Allows the admin to print tickets for any booking.',
	 'details' => 'Adds a button "print selected entries" to let an admin print arbitrary tickets (whether they have been paid or not), for instance for customers who are having trouble printing their tickets.');
}

?>